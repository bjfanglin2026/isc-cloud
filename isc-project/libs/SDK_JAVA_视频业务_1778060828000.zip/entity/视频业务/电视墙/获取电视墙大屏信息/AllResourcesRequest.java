public class AllResourcesRequest {
}
