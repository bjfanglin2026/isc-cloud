public class RootOrgRequest {
}
